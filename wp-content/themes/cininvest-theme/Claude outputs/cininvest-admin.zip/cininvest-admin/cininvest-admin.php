<?php
/**
 * Plugin Name: CININVEST — Админка
 * Description: Заявки (данные, статус, «Одобрить → создать проект»), верификация пользователей, финансовые операции, сводка и быстрая правка проектов. Требует тему CININVEST (CPT project/application, ACF-поля).
 * Version: 1.2.0
 * Author: CININVEST
 */
if (!defined('ABSPATH')) exit;

define('CININVEST_ADMIN_VERSION', '1.2.0');

/**
 * Зависимость от темы: если CPT application/project ещё не зарегистрированы
 * (например, активирован не тот сайт/тема) — тихо не подключаем функционал,
 * но предупреждаем в админке, чтобы не гадать почему «ничего не работает».
 */
add_action('admin_init', function () {
    if (!post_type_exists('application') || !post_type_exists('project')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-warning"><p><b>CININVEST — Админка заявок:</b> не найдены типы записей «application»/«project». Плагин рассчитан на работу вместе с темой CININVEST — проверьте, что она активна.</p></div>';
        });
    }
});

/* =========================================================================
 * 1. Колонки «Статус» и «Проект» в списке заявок (Заявки → Все заявки)
 * ========================================================================= */

add_filter('manage_application_posts_columns', function ($columns) {
    // вставляем новые колонки перед датой (последней колонкой по умолчанию)
    $date = $columns['date'] ?? null;
    unset($columns['date']);
    $columns['cininvest_status'] = 'Статус';
    $columns['cininvest_project'] = 'Проект';
    if ($date) $columns['date'] = $date;
    return $columns;
});

add_action('manage_application_posts_custom_column', function ($column, $post_id) {
    if ($column === 'cininvest_status') {
        $terms = get_the_terms($post_id, 'application_status');
        $term = (!is_wp_error($terms) && $terms) ? $terms[0] : null;
        echo $term ? '<span class="cininvest-status cininvest-status--' . esc_attr($term->slug) . '">' . esc_html($term->name) . '</span>' : '—';
    }
    if ($column === 'cininvest_project') {
        $project_id = (int) get_post_meta($post_id, '_cininvest_created_project', true);
        if ($project_id && get_post($project_id)) {
            echo '<a href="' . esc_url(get_edit_post_link($project_id)) . '">' . esc_html(get_the_title($project_id)) . '</a>';
        } else {
            echo '—';
        }
    }
}, 10, 2);

// Лёгкая раскраска статусов в списке (одобрена/отклонена выделяются)
add_action('admin_head-edit.php', function () {
    global $post_type;
    if ($post_type !== 'application') return;
    echo '<style>
        .cininvest-status{display:inline-block;padding:2px 8px;border-radius:3px;font-size:12px;background:#eee}
        .cininvest-status--approved{background:#d4f7d4;color:#1e6b1e}
        .cininvest-status--rejected{background:#f7d4d4;color:#8a1f1f}
        .cininvest-status--submitted{background:#fff3cd;color:#7a5b00}
    </style>';
});

/* =========================================================================
 * 2. Метабокс на странице заявки: статус, файлы, кнопки действий
 * ========================================================================= */

add_action('add_meta_boxes', function () {
    add_meta_box(
        'cininvest_application_actions',
        'CININVEST: Заявка',
        'cininvest_admin_render_application_metabox',
        'application',
        'side',
        'high'
    );
    add_meta_box(
        'cininvest_application_data',
        'CININVEST: Данные заявки',
        'cininvest_admin_render_application_data_metabox',
        'application',
        'normal',
        'high'
    );
});

function cininvest_admin_render_application_metabox($post) {
    $terms = get_the_terms($post->ID, 'application_status');
    $status_slug = (!is_wp_error($terms) && $terms) ? $terms[0]->slug : 'draft';
    $status_name = (!is_wp_error($terms) && $terms) ? $terms[0]->name : 'Черновик';
    $project_id = (int) get_post_meta($post->ID, '_cininvest_created_project', true);

    echo '<p><b>Статус:</b> ' . esc_html($status_name) . '</p>';

    // ссылки на загруженные файлы заявки — чтобы не искать их по метаполям вручную
    $files = [
        'script_file' => 'Сценарий', 'presentation_file' => 'Презентация', 'sizzle_file' => 'Сайзл-рил',
        'estimate_file' => 'Смета', 'recommendations_file' => 'Рекомендательные письма',
    ];
    $has_files = false;
    echo '<p><b>Файлы:</b></p><ul style="margin:0 0 12px">';
    foreach ($files as $meta_key => $label) {
        $att_id = (int) get_post_meta($post->ID, $meta_key, true);
        if (!$att_id) continue;
        $has_files = true;
        echo '<li><a href="' . esc_url(wp_get_attachment_url($att_id)) . '" target="_blank" rel="noopener">' . esc_html($label) . '</a></li>';
    }
    if (!$has_files) echo '<li style="color:#888">файлы не загружены</li>';
    echo '</ul>';

    if (!current_user_can('manage_options')) {
        echo '<p style="color:#888">Действия доступны только администратору.</p>';
        return;
    }

    if ($project_id && get_post($project_id)) {
        echo '<p><a class="button button-primary" href="' . esc_url(get_edit_post_link($project_id)) . '">Открыть проект →</a></p>';
        echo '<p style="color:#888;font-size:12px">Проект уже создан из этой заявки — повторное нажатие «Одобрить» его не задублирует.</p>';
    }

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-bottom:8px">';
    echo '<input type="hidden" name="action" value="cininvest_admin_approve_project">';
    echo '<input type="hidden" name="application_id" value="' . (int) $post->ID . '">';
    wp_nonce_field('cininvest_admin_approve_' . $post->ID, 'cininvest_admin_nonce');
    $btn_label = $project_id ? 'Пересоздать данные проекта' : 'Одобрить и создать проект';
    echo '<button type="submit" class="button' . ($project_id ? '' : ' button-primary') . '" style="width:100%">' . esc_html($btn_label) . '</button>';
    echo '</form>';

    if ($status_slug !== 'rejected') {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="cininvest_admin_reject_application">';
        echo '<input type="hidden" name="application_id" value="' . (int) $post->ID . '">';
        wp_nonce_field('cininvest_admin_reject_' . $post->ID, 'cininvest_admin_nonce');
        echo '<button type="submit" class="button" style="width:100%;color:#a00" onclick="return confirm(\'Отклонить заявку?\')">Отклонить</button>';
        echo '</form>';
    }
}

/* =========================================================================
 * 2b. Метабокс с полными данными заявки (широкий, под заголовком).
 *     У CPT application нет редактора, а панель «Произвольные поля» в
 *     Gutenberg по умолчанию выключена — без этого блока заявка в
 *     админке выглядит пустой. Группировка полей повторяет шаги формы
 *     подачи заявки (page-application.php).
 * ========================================================================= */

function cininvest_admin_row($label, $value_html) {
    if ($value_html === '' || $value_html === null) return;
    echo '<div class="cininvest-appdata__label">' . esc_html($label) . '</div><div class="cininvest-appdata__value">' . $value_html . '</div>';
}

function cininvest_admin_render_application_data_metabox($post) {
    $app_id = $post->ID;
    $m = function ($key) use ($app_id) {
        $v = get_post_meta($app_id, $key, true);
        return is_string($v) ? trim($v) : $v;
    };
    $money = function ($v) { return $v === '' ? '' : esc_html($v) . ' ₽'; };
    $is_ur = $m('applicant_type') === 'ur';

    echo '<style>
        .cininvest-appdata__section{margin:0 0 22px;padding-bottom:18px;border-bottom:1px solid #dcdcde}
        .cininvest-appdata__section:last-child{border-bottom:0;margin-bottom:0;padding-bottom:0}
        .cininvest-appdata__section h3{margin:0 0 12px;font-size:14px}
        .cininvest-appdata__grid{display:grid;grid-template-columns:280px 1fr;gap:8px 16px}
        .cininvest-appdata__label{color:#646970;padding:4px 0}
        .cininvest-appdata__value{padding:4px 0;word-break:break-word}
        .cininvest-appdata__empty{color:#888;font-style:italic}
    </style>';

    echo '<p style="margin-top:0"><b>Тип заявителя:</b> ' . ($is_ur ? 'Юридическое лицо' : 'Физическое лицо') . '</p>';
    echo '<div class="cininvest-appdata">';

    // --- Заявитель (юрлицо) / Мои данные (физлицо) ---
    echo '<div class="cininvest-appdata__section"><h3>' . ($is_ur ? 'Заявитель' : 'Мои данные') . '</h3><div class="cininvest-appdata__grid">';
    if ($is_ur) {
        cininvest_admin_row('Полное наименование Заявителя', esc_html($m('org_name')));
        cininvest_admin_row('Руководитель организации', esc_html(trim($m('ceo_last') . ' ' . $m('ceo_first') . ' ' . $m('ceo_middle'))));
        cininvest_admin_row('Должность', esc_html($m('position')));
        cininvest_admin_row('Контактный телефон Заявителя', esc_html($m('applicant_phone')));
    } else {
        cininvest_admin_row('Образование', esc_html($m('education')));
        foreach (['edu_org' => 'Образовательные организации и специальности', 'experience' => 'Опыт работы', 'social' => 'Социальные сети'] as $key => $label) {
            $vals = get_post_meta($app_id, $key, true);
            $vals = is_array($vals) ? array_filter(array_map('trim', $vals), 'strlen') : [];
            if ($vals) cininvest_admin_row($label, implode('<br>', array_map('esc_html', $vals)));
        }
        cininvest_admin_row('Дополнительно', esc_html($m('additional')));
        cininvest_admin_row('Контактный телефон Заявителя', esc_html($m('applicant_phone')));
    }
    echo '</div></div>';

    // --- Проект (без «Название проекта» — оно уже заголовок записи) ---
    echo '<div class="cininvest-appdata__section"><h3>Проект</h3><div class="cininvest-appdata__grid">';
    foreach ([
        'genre' => 'Жанр', 'duration' => 'Хронометраж', 'ptype' => 'Тип', 'kind' => 'Вид',
        'logline' => 'Логлайн', 'idea' => 'Оригинальная идея / Хай-концепт', 'setting' => 'Сеттинг',
        'annotation' => 'Аннотация', 'synopsis' => 'Синопсис', 'locations' => 'Локации',
    ] as $key => $label) {
        cininvest_admin_row($label, esc_html($m($key)));
    }
    echo '</div></div>';

    // --- Создатели фильма ---
    echo '<div class="cininvest-appdata__section"><h3>Создатели фильма</h3><div class="cininvest-appdata__grid">';
    if ($is_ur) cininvest_admin_row('Кинокомпания', esc_html($m('company')));
    cininvest_admin_row('ФИО Руководителя', esc_html($m('head_fio')));
    foreach (['producer' => 'Продюсер', 'director' => 'Режиссёр', 'writer' => 'Авторы сценария', 'operator' => 'Оператор', 'artist' => 'Художник', 'composer' => 'Композитор'] as $key => $label) {
        $fio = $m($key . '_fio');
        if ($fio === '') continue;
        $kp = $m($key . '_kp');
        $val = esc_html($fio);
        if ($kp !== '') {
            $val .= ' · Кинопоиск: ' . (preg_match('~^https?://~i', $kp) ? '<a href="' . esc_url($kp) . '" target="_blank" rel="noopener">' . esc_html($kp) . '</a>' : esc_html($kp));
        }
        cininvest_admin_row($label, $val);
    }
    echo '</div></div>';

    // --- Календарный план ---
    echo '<div class="cininvest-appdata__section"><h3>Календарный план</h3><div class="cininvest-appdata__grid">';
    $period_labels = ['Подготовительный период', 'Съемочный/производственный период', 'Монтажно-тонировочный период', 'Прокат'];
    $periods = get_post_meta($app_id, 'periods', true);
    $periods = is_array($periods) ? $periods : [];
    $any_period = false;
    foreach ($period_labels as $i => $label) {
        $pd = $periods[$i] ?? [];
        if (empty($pd['active'])) continue;
        $any_period = true;
        $range = trim(($pd['start'] ?? '') . ' – ' . ($pd['end'] ?? ''), ' –');
        cininvest_admin_row($label, esc_html($range !== '' ? $range : 'даты не указаны'));
    }
    if (!$any_period) echo '<div class="cininvest-appdata__label">Этапы</div><div class="cininvest-appdata__value cininvest-appdata__empty">не отмечены</div>';
    cininvest_admin_row('Общий срок производства (в месяцах)', esc_html($m('total_duration')));
    echo '</div></div>';

    // --- Финансирование производства ---
    echo '<div class="cininvest-appdata__section"><h3>Источники финансирования производства</h3><div class="cininvest-appdata__grid">';
    cininvest_admin_row('Сметная стоимость производства', $money($m('budget')));
    cininvest_admin_row('Собственные средства', $money($m('own_funds')));
    cininvest_admin_row('Запрашиваемая сумма', $money($m('requested')));
    cininvest_admin_row('Уже потрачено на проект', $money($m('spent')));
    echo '</div></div>';

    // --- Реквизиты заявителя (набор полей зависит от типа заявителя) ---
    echo '<div class="cininvest-appdata__section"><h3>Реквизиты заявителя</h3><div class="cininvest-appdata__grid">';
    $req_fields = $is_ur
        ? ['legal_address' => 'Юридический адрес Заявителя', 'ogrn' => 'ОГРН', 'inn' => 'ИНН Заявителя', 'kpp' => 'КПП Заявителя', 'ogrn_date' => 'Дата присвоения ОГРН', 'okved' => 'Основной ОКВЭД Заявителя', 'bik' => 'БИК Банка Заявителя', 'bank_name' => 'Наименование банка Заявителя', 'corr_account' => 'Номер корреспондентского счёта банка Заявителя', 'settle_account' => 'Номер расчётного счёта в банке Заявителя']
        : ['inn' => 'ИНН', 'snils' => 'СНИЛС', 'bank_name' => 'Наименование банка', 'bik' => 'БИК банка', 'corr_account' => 'Номер корреспондентского счёта', 'settle_account' => 'Номер расчётного счёта'];
    foreach ($req_fields as $key => $label) {
        cininvest_admin_row($label, esc_html($m($key)));
    }
    echo '</div></div>';

    // --- Вознаграждения ---
    $rewards = get_post_meta($app_id, 'rewards', true);
    $rewards = is_array($rewards) ? array_filter($rewards) : [];
    echo '<div class="cininvest-appdata__section"><h3>Вознаграждения</h3><div class="cininvest-appdata__grid">';
    if ($rewards) {
        cininvest_admin_row('Выбрано', implode('<br>', array_map('esc_html', $rewards)));
    } else {
        echo '<div class="cininvest-appdata__label">Выбрано</div><div class="cininvest-appdata__value cininvest-appdata__empty">ничего не выбрано</div>';
    }
    echo '</div></div>';

    echo '</div>';
}

/* =========================================================================
 * 3. Обработчик «Одобрить и создать проект»
 * ========================================================================= */

add_action('admin_post_cininvest_admin_approve_project', function () {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');

    $app_id = (int) ($_POST['application_id'] ?? 0);
    if (!$app_id || !check_admin_referer('cininvest_admin_approve_' . $app_id, 'cininvest_admin_nonce')) {
        wp_die('Ошибка безопасности');
    }
    $application = get_post($app_id);
    if (!$application || $application->post_type !== 'application') wp_die('Заявка не найдена');

    $m = function ($key, $fallback = '') use ($app_id) {
        $v = get_post_meta($app_id, $key, true);
        return $v !== '' ? $v : $fallback;
    };

    // числа могли прийти с пробелами/₽ из текстового поля — оставляем только цифры
    $to_number = function ($s) {
        return (float) preg_replace('/[^\d.]/', '', (string) $s);
    };

    $existing_project_id = (int) get_post_meta($app_id, '_cininvest_created_project', true);

    if ($existing_project_id && get_post($existing_project_id)) {
        $project_id = $existing_project_id; // обновляем данные, не плодим дубли
    } else {
        $project_id = wp_insert_post([
            'post_type' => 'project',
            'post_status' => 'draft',
            'post_title' => $m('project_name', $application->post_title),
            'post_content' => $m('annotation', $m('synopsis', '')),
            'post_author' => $application->post_author,
        ], true);
        if (is_wp_error($project_id)) wp_die('Не удалось создать проект: ' . $project_id->get_error_message());
    }

    if (function_exists('update_field')) {
        // --- О проекте ---
        foreach ([
            'org_name' => 'org_name', 'genre' => 'genre', 'duration' => 'duration', 'ptype' => 'ptype',
            'kind' => 'kind', 'logline' => 'logline', 'idea' => 'idea', 'setting' => 'setting',
            'annotation' => 'annotation', 'synopsis' => 'synopsis', 'locations' => 'locations',
        ] as $app_key => $acf_key) {
            $v = $m($app_key);
            if ($v !== '') update_field($acf_key, $v, $project_id);
        }

        // --- Цель сбора: «Запрашиваемая сумма» заявки -> ACF goal ---
        $requested = $to_number($m('requested', 0));
        if ($requested > 0) update_field('goal', $requested, $project_id);
        // collected не трогаем при пересоздании — если уже что-то собрано, не обнуляем
        if (!$existing_project_id) update_field('collected', 0, $project_id);

        // --- Команда: именные роли заявки -> repeater team ---
        $roles = [
            'producer' => 'Продюсер', 'director' => 'Режиссёр', 'writer' => 'Автор сценария',
            'operator' => 'Оператор', 'artist' => 'Художник', 'composer' => 'Композитор',
        ];
        $team = [];
        $head_fio = $m('head_fio');
        if ($head_fio) $team[] = ['name' => $head_fio, 'role' => 'Руководитель', 'about' => '', 'kinopoisk' => ''];
        foreach ($roles as $key => $label) {
            $fio = $m($key . '_fio');
            if (!$fio) continue;
            $team[] = ['name' => $fio, 'role' => $label, 'about' => '', 'kinopoisk' => $m($key . '_kp')];
        }
        if ($team) update_field('team', $team, $project_id);

        // --- Вознаграждения: выбранные в заявке чекбоксы -> repeater rewards, цена по умолчанию 500₽
        //     (в заявке цена не запрашивается — соответствует текущему каталогу на сайте, админ может поправить) ---
        $checked_rewards = get_post_meta($app_id, 'rewards', true);
        if (is_array($checked_rewards) && $checked_rewards) {
            $rewards = array_map(function ($title) { return ['title' => $title, 'price' => 500]; }, $checked_rewards);
            update_field('rewards', $rewards, $project_id);
        }

        // --- Файлы: сценарий/презентация/сайзл -> materials, смета/рекомендации -> docs ---
        $materials = [];
        foreach (['script_file' => 'Сценарий', 'presentation_file' => 'Презентация', 'sizzle_file' => 'Сайзл-рил'] as $meta_key => $label) {
            $att_id = (int) get_post_meta($app_id, $meta_key, true);
            if ($att_id) $materials[] = ['title' => $label, 'file' => $att_id];
        }
        if ($materials) update_field('materials', $materials, $project_id);

        $docs = [];
        foreach (['estimate_file' => 'Смета', 'recommendations_file' => 'Рекомендательные письма'] as $meta_key => $label) {
            $att_id = (int) get_post_meta($app_id, $meta_key, true);
            if ($att_id) $docs[] = ['title' => $label, 'file' => $att_id];
        }
        if ($docs) update_field('docs', $docs, $project_id);
    }

    // перекрёстные ссылки + статус заявки
    update_post_meta($project_id, '_cininvest_source_application', $app_id);
    update_post_meta($app_id, '_cininvest_created_project', $project_id);
    wp_set_object_terms($app_id, 'approved', 'application_status');

    wp_safe_redirect(add_query_arg('cininvest_notice', 'approved', get_edit_post_link($project_id, 'raw')));
    exit;
});

/* =========================================================================
 * 4. Обработчик «Отклонить»
 * ========================================================================= */

add_action('admin_post_cininvest_admin_reject_application', function () {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');

    $app_id = (int) ($_POST['application_id'] ?? 0);
    if (!$app_id || !check_admin_referer('cininvest_admin_reject_' . $app_id, 'cininvest_admin_nonce')) {
        wp_die('Ошибка безопасности');
    }

    wp_set_object_terms($app_id, 'rejected', 'application_status');
    wp_safe_redirect(add_query_arg('cininvest_notice', 'rejected', get_edit_post_link($app_id, 'raw')));
    exit;
});

/* =========================================================================
 * 5. Уведомление после редиректа (создан проект / заявка отклонена)
 * ========================================================================= */

add_action('admin_notices', function () {
    if (empty($_GET['cininvest_notice'])) return;
    if ($_GET['cininvest_notice'] === 'approved') {
        echo '<div class="notice notice-success is-dismissible"><p>Проект создан как черновик из данных заявки. Проверьте поля (особенно цену за долю и комиссию — их заявка не передаёт) и опубликуйте, когда всё готово.</p></div>';
    } elseif ($_GET['cininvest_notice'] === 'rejected') {
        echo '<div class="notice notice-warning is-dismissible"><p>Заявка отмечена как отклонённая.</p></div>';
    }
});

/* =========================================================================
 * 6. Меню админки CININVEST: Сводка / Верификации / Операции.
 * ========================================================================= */

function cininvest_admin_money($v) {
    return function_exists('cininvest_money') ? cininvest_money($v) : number_format((float) $v, 0, ',', ' ') . ' ₽';
}

add_action('admin_menu', function () {
    add_menu_page('CININVEST', 'CININVEST', 'manage_options', 'cininvest-admin', 'cininvest_admin_render_dashboard_page', 'dashicons-money-alt', 30);
    add_submenu_page('cininvest-admin', 'Сводка', 'Сводка', 'manage_options', 'cininvest-admin', 'cininvest_admin_render_dashboard_page');
    add_submenu_page('cininvest-admin', 'Верификации', 'Верификации', 'manage_options', 'cininvest-verifications', 'cininvest_admin_render_verifications_page');
    $ops_hook = add_submenu_page('cininvest-admin', 'Операции', 'Операции', 'manage_options', 'cininvest-operations', 'cininvest_admin_render_operations_page');
    add_action('load-' . $ops_hook, 'cininvest_admin_maybe_export_operations_csv');
});

/** Общие стили: страницы CININVEST + список/быстрая правка проектов (карточки, бейджи, таблицы) */
add_action('admin_head', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    $id = $screen ? (string) $screen->id : '';
    if (strpos($id, 'cininvest') === false && !in_array($id, ['edit-project', 'edit-application'], true)) return;
    echo '<style>
        .cininvest-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin:20px 0}
        .cininvest-card{background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:16px 18px}
        .cininvest-card h3{margin:0 0 10px;font-size:13px;color:#646970;font-weight:600;text-transform:uppercase}
        .cininvest-card__row{display:flex;justify-content:space-between;align-items:baseline;padding:4px 0;gap:12px}
        .cininvest-card__num{font-size:22px;font-weight:600}
        .cininvest-card__num--warn{color:#b32d2e}
        .cininvest-card__link{font-size:12px;margin:10px 0 0}
        .cininvest-badge{display:inline-block;padding:2px 8px;border-radius:3px;font-size:12px;background:#eee;white-space:nowrap}
        .cininvest-badge--checking{background:#fff3cd;color:#7a5b00}
        .cininvest-badge--completed{background:#d4f7d4;color:#1e6b1e}
        .cininvest-badge--rejected{background:#f7d4d4;color:#8a1f1f}
        .cininvest-badge--none{background:#eee;color:#888}
        .cininvest-tabs{margin:10px 0 16px}
        .cininvest-tabs a{margin-right:16px;text-decoration:none}
        .cininvest-tabs a.is-active{font-weight:600;color:#1d2327}
        .cininvest-table td,.cininvest-table th{vertical-align:middle}
        .cininvest-detail dl{display:grid;grid-template-columns:220px 1fr;gap:6px 16px;margin:0}
        .cininvest-detail dt{color:#646970}
        .cininvest-detail dd{margin:0}
        .cininvest-detail h2{margin:24px 0 10px;font-size:15px}
        .cininvest-detail h2:first-child{margin-top:0}
        .inline-edit-cininvest h4{margin:0 0 8px}
    </style>';
});

/* =========================================================================
 * 6a. Сводка — карточки со сквозными цифрами по заявкам/верификациям/
 *     проектам/финансам, чтобы не собирать картину по разным экранам.
 * ========================================================================= */

function cininvest_admin_render_dashboard_page() {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');
    global $wpdb;

    $count_apps = function ($slug) {
        $q = new WP_Query([
            'post_type' => 'application', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids',
            'tax_query' => [['taxonomy' => 'application_status', 'field' => 'slug', 'terms' => $slug]],
        ]);
        return (int) $q->found_posts;
    };
    $apps_submitted = $count_apps('submitted');
    $apps_approved = $count_apps('approved');
    $apps_rejected = $count_apps('rejected');

    $count_verify = function ($status) {
        $q = new WP_User_Query(['meta_key' => 'cininvest_verify_status', 'meta_value' => $status, 'fields' => 'ID', 'number' => 1]);
        return (int) $q->get_total();
    };
    $v_checking = $count_verify('checking');
    $v_completed = $count_verify('completed');
    $v_rejected = $count_verify('rejected');

    $count_projects = function ($status) {
        $q = new WP_Query([
            'post_type' => 'project', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids',
            'meta_query' => [['key' => 'project_status', 'value' => $status]],
        ]);
        return (int) $q->found_posts;
    };
    $p_active = $count_projects('active');
    $p_completed = $count_projects('completed');
    $collected_total = (float) $wpdb->get_var("
        SELECT SUM(CAST(pm.meta_value AS DECIMAL(15,2))) FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = 'collected' AND p.post_type = 'project' AND p.post_status = 'publish'
    ");

    $ops_table = $wpdb->prefix . 'cininvest_operations';
    $ops_completed_sum = (float) $wpdb->get_var("SELECT SUM(amount) FROM {$ops_table} WHERE status = 'completed'");
    $ops_pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$ops_table} WHERE status = 'pending'");
    $ops_failed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$ops_table} WHERE status = 'failed'");
    $ops_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$ops_table}");

    echo '<div class="wrap"><h1>CININVEST — Сводка</h1><div class="cininvest-cards">';

    echo '<div class="cininvest-card"><h3>Заявки</h3>';
    echo '<div class="cininvest-card__row"><span>На рассмотрении</span><b class="cininvest-card__num' . ($apps_submitted ? ' cininvest-card__num--warn' : '') . '">' . (int) $apps_submitted . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Одобрено</span><b>' . (int) $apps_approved . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Отклонено</span><b>' . (int) $apps_rejected . '</b></div>';
    echo '<p class="cininvest-card__link"><a href="' . esc_url(admin_url('edit.php?post_type=application')) . '">Все заявки →</a></p></div>';

    echo '<div class="cininvest-card"><h3>Верификация</h3>';
    echo '<div class="cininvest-card__row"><span>На проверке</span><b class="cininvest-card__num' . ($v_checking ? ' cininvest-card__num--warn' : '') . '">' . (int) $v_checking . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Подтверждено</span><b>' . (int) $v_completed . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Отклонено</span><b>' . (int) $v_rejected . '</b></div>';
    echo '<p class="cininvest-card__link"><a href="' . esc_url(admin_url('admin.php?page=cininvest-verifications')) . '">Все верификации →</a></p></div>';

    echo '<div class="cininvest-card"><h3>Проекты</h3>';
    echo '<div class="cininvest-card__row"><span>В работе</span><b>' . (int) $p_active . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Завершено</span><b>' . (int) $p_completed . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Собрано всего</span><b>' . esc_html(cininvest_admin_money($collected_total)) . '</b></div>';
    echo '<p class="cininvest-card__link"><a href="' . esc_url(admin_url('edit.php?post_type=project')) . '">Все проекты →</a></p></div>';

    echo '<div class="cininvest-card"><h3>Финансы</h3>';
    echo '<div class="cininvest-card__row"><span>Операций всего</span><b>' . (int) $ops_total . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Сумма (завершённых)</span><b>' . esc_html(cininvest_admin_money($ops_completed_sum)) . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Ожидают</span><b class="cininvest-card__num' . ($ops_pending ? ' cininvest-card__num--warn' : '') . '">' . (int) $ops_pending . '</b></div>';
    echo '<div class="cininvest-card__row"><span>Неуспешных</span><b class="cininvest-card__num' . ($ops_failed ? ' cininvest-card__num--warn' : '') . '">' . (int) $ops_failed . '</b></div>';
    echo '<p class="cininvest-card__link"><a href="' . esc_url(admin_url('admin.php?page=cininvest-operations')) . '">Все операции →</a></p></div>';

    echo '</div></div>';
}

/* =========================================================================
 * 7. Верификации пользователей (физлицо/ИП/юрлицо).
 *    Хранится в user-meta (inc/forms-verification.php) — своего CPT нет,
 *    поэтому список/детали — отдельная страница, не edit.php. Раньше в теме
 *    подтверждение верификации было заготовкой на будущее (cininvest_complete_verification
 *    нигде не вызывалась) — этот блок и есть то самое «позже».
 * ========================================================================= */

function cininvest_admin_verify_type_label($vtype) {
    $labels = ['fiz' => 'Физическое лицо', 'ip' => 'ИП', 'ur' => 'Юридическое лицо'];
    return $labels[$vtype] ?? '—';
}
function cininvest_admin_verify_status_label($status) {
    $labels = ['checking' => 'На проверке', 'completed' => 'Подтверждено', 'rejected' => 'Отклонено'];
    return $labels[$status] ?? 'Не начата';
}
function cininvest_admin_verify_badge($status) {
    $slug = in_array($status, ['checking', 'completed', 'rejected'], true) ? $status : 'none';
    return '<span class="cininvest-badge cininvest-badge--' . esc_attr($slug) . '">' . esc_html(cininvest_admin_verify_status_label($status)) . '</span>';
}

function cininvest_admin_render_verifications_page() {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');

    $user_id = (int) ($_GET['user_id'] ?? 0);
    if ($user_id) {
        cininvest_admin_render_verification_detail($user_id);
        return;
    }

    $status = $_GET['status'] ?? 'checking';
    if (!in_array($status, ['all', 'checking', 'completed', 'rejected'], true)) $status = 'checking';

    $args = ['meta_key' => 'cininvest_verify_status', 'number' => 100, 'orderby' => 'ID', 'order' => 'DESC'];
    if ($status !== 'all') { $args['meta_value'] = $status; } else { $args['meta_compare'] = 'EXISTS'; }
    $query = new WP_User_Query($args);
    $users = $query->get_results();

    echo '<div class="wrap"><h1>Верификации</h1>';

    if (!empty($_GET['cininvest_notice'])) {
        $ok = $_GET['cininvest_notice'] === 'approved';
        echo '<div class="notice notice-' . ($ok ? 'success' : 'warning') . ' is-dismissible"><p>' . ($ok ? 'Верификация подтверждена.' : 'Верификация отклонена.') . '</p></div>';
    }

    $tabs = ['checking' => 'На проверке', 'completed' => 'Подтверждено', 'rejected' => 'Отклонено', 'all' => 'Все'];
    echo '<div class="cininvest-tabs">';
    foreach ($tabs as $slug => $label) {
        $url = esc_url(add_query_arg(['page' => 'cininvest-verifications', 'status' => $slug], admin_url('admin.php')));
        echo '<a class="' . ($status === $slug ? 'is-active' : '') . '" href="' . $url . '">' . esc_html($label) . '</a>';
    }
    echo '</div>';

    echo '<table class="wp-list-table widefat fixed striped cininvest-table"><thead><tr><th>Пользователь</th><th>Тип</th><th>ПДЛ</th><th>Статус</th><th></th></tr></thead><tbody>';
    if ($users) {
        foreach ($users as $u) {
            $vtype = get_user_meta($u->ID, 'cininvest_verify_type', true);
            $vstatus = get_user_meta($u->ID, 'cininvest_verify_status', true);
            $pdl = get_user_meta($u->ID, 'cininvest_is_pdl', true);
            $detail_url = esc_url(add_query_arg(['page' => 'cininvest-verifications', 'user_id' => $u->ID], admin_url('admin.php')));
            echo '<tr>';
            echo '<td><a href="' . $detail_url . '"><b>' . esc_html($u->display_name) . '</b></a><br><span style="color:#646970">' . esc_html($u->user_email) . '</span></td>';
            echo '<td>' . esc_html(cininvest_admin_verify_type_label($vtype)) . '</td>';
            echo '<td>' . ($pdl === 'yes' ? '<b style="color:#b32d2e">Да</b>' : ($pdl === 'no' ? 'Нет' : '—')) . '</td>';
            echo '<td>' . cininvest_admin_verify_badge($vstatus) . '</td>';
            echo '<td><a class="button button-small" href="' . $detail_url . '">Открыть →</a></td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="5">Ничего не найдено.</td></tr>';
    }
    echo '</tbody></table></div>';
}

function cininvest_admin_render_verification_detail($user_id) {
    $user = get_userdata($user_id);
    if (!$user) { echo '<div class="wrap"><h1>Верификации</h1><p>Пользователь не найден.</p></div>'; return; }

    $m = function ($key) use ($user_id) { return trim((string) get_user_meta($user_id, $key, true)); };
    $vtype = $m('cininvest_verify_type');
    $vstatus = $m('cininvest_verify_status');
    $back_url = esc_url(remove_query_arg(['user_id', 'cininvest_notice']));

    echo '<div class="wrap"><h1>Верификация: ' . esc_html($user->display_name) . '</h1>';
    echo '<p><a href="' . $back_url . '">← Ко всем верификациям</a></p>';

    if (!empty($_GET['cininvest_notice'])) {
        $ok = $_GET['cininvest_notice'] === 'approved';
        echo '<div class="notice notice-' . ($ok ? 'success' : 'warning') . ' is-dismissible"><p>' . ($ok ? 'Верификация подтверждена.' : 'Верификация отклонена.') . '</p></div>';
    }

    echo '<div class="cininvest-cards" style="grid-template-columns:1fr 1fr 1fr">';
    echo '<div class="cininvest-card"><h3>Пользователь</h3><p style="margin:0"><a href="' . esc_url(get_edit_user_link($user_id)) . '">' . esc_html($user->display_name) . '</a><br>' . esc_html($user->user_email) . '</p></div>';
    echo '<div class="cininvest-card"><h3>Тип</h3><p style="margin:0">' . esc_html(cininvest_admin_verify_type_label($vtype)) . '</p></div>';
    echo '<div class="cininvest-card"><h3>Статус</h3><p style="margin:0">' . cininvest_admin_verify_badge($vstatus) . '</p></div>';
    echo '</div>';

    $pdl = $m('cininvest_is_pdl');
    if ($pdl !== '') {
        echo '<p><b>Публичное должностное лицо:</b> ' . ($pdl === 'yes' ? '<b style="color:#b32d2e">Да</b>' : 'Нет') . '</p>';
    }

    echo '<div class="cininvest-detail">';

    echo '<h2>Паспортные данные</h2><dl>';
    $reg_address = $m('cininvest_v_reg_address');
    if ($reg_address !== '') echo '<dt>Адрес регистрации</dt><dd>' . esc_html($reg_address) . '</dd>';
    echo '</dl>';

    $docs = [
        'cininvest_v_passport_photo' => 'Паспорт (фото)', 'cininvest_v_passport_reg' => 'Паспорт (прописка)',
        'cininvest_v_egrip' => 'Выписка ЕГРИП', 'cininvest_v_charter' => 'Устав', 'cininvest_v_authority' => 'Документ о полномочиях',
    ];
    $doc_links = [];
    foreach ($docs as $meta_key => $label) {
        $att_id = (int) get_user_meta($user_id, $meta_key, true);
        if ($att_id) $doc_links[] = '<a href="' . esc_url(wp_get_attachment_url($att_id)) . '" target="_blank" rel="noopener">' . esc_html($label) . '</a>';
    }
    echo '<h2>Документы</h2><p>' . ($doc_links ? implode(' · ', $doc_links) : '<span style="color:#888">не загружены</span>') . '</p>';

    echo '<h2>Юридические данные</h2><dl>';
    $inn = $m('cininvest_v_inn');
    $ogrn = $m('cininvest_v_ogrn');
    if ($inn !== '') echo '<dt>ИНН</dt><dd>' . esc_html($inn) . '</dd>';
    if ($ogrn !== '') echo '<dt>' . ($vtype === 'ip' ? 'ОГРНИП' : 'ОГРН') . '</dt><dd>' . esc_html($ogrn) . '</dd>';
    echo '</dl>';

    echo '<h2>Реквизиты счёта</h2><dl>';
    foreach (['cininvest_v_account' => 'Номер счёта', 'cininvest_v_bik' => 'БИК', 'cininvest_v_bank_name' => 'Наименование банка', 'cininvest_v_corr_account' => 'Корреспондентский счёт'] as $key => $label) {
        $v = $m($key);
        if ($v !== '') echo '<dt>' . esc_html($label) . '</dt><dd>' . esc_html($v) . '</dd>';
    }
    echo '</dl>';

    $reject_reason = $m('cininvest_verify_reject_reason');
    if ($vstatus === 'rejected' && $reject_reason !== '') {
        echo '<h2>Причина отказа</h2><p>' . esc_html($reject_reason) . '</p>';
    }

    echo '</div>';

    if ($vstatus !== 'completed') {
        echo '<h2 style="margin-top:24px">Подтвердить</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-bottom:16px">';
        echo '<input type="hidden" name="action" value="cininvest_admin_approve_verification"><input type="hidden" name="user_id" value="' . (int) $user_id . '">';
        wp_nonce_field('cininvest_admin_verify_approve_' . $user_id, 'cininvest_admin_nonce');
        echo '<button type="submit" class="button button-primary">Подтвердить верификацию</button></form>';
    }
    if ($vstatus !== 'rejected') {
        echo '<h2 style="margin-top:0">Отклонить</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="cininvest_admin_reject_verification"><input type="hidden" name="user_id" value="' . (int) $user_id . '">';
        wp_nonce_field('cininvest_admin_verify_reject_' . $user_id, 'cininvest_admin_nonce');
        echo '<p><textarea name="reject_reason" rows="2" style="width:100%;max-width:480px" placeholder="Причина отказа (необязательно)"></textarea></p>';
        echo '<button type="submit" class="button" style="color:#a00" onclick="return confirm(\'Отклонить верификацию?\')">Отклонить верификацию</button></form>';
    }

    echo '</div>';
}

add_action('admin_post_cininvest_admin_approve_verification', function () {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');
    $user_id = (int) ($_POST['user_id'] ?? 0);
    if (!$user_id || !check_admin_referer('cininvest_admin_verify_approve_' . $user_id, 'cininvest_admin_nonce')) {
        wp_die('Ошибка безопасности');
    }
    if (function_exists('cininvest_complete_verification')) {
        cininvest_complete_verification($user_id);
    } else {
        update_user_meta($user_id, 'cininvest_verify_status', 'completed');
        update_user_meta($user_id, 'cininvest_verified', 1);
    }
    delete_user_meta($user_id, 'cininvest_verify_reject_reason');
    wp_safe_redirect(add_query_arg(['page' => 'cininvest-verifications', 'user_id' => $user_id, 'cininvest_notice' => 'approved'], admin_url('admin.php')));
    exit;
});

add_action('admin_post_cininvest_admin_reject_verification', function () {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');
    $user_id = (int) ($_POST['user_id'] ?? 0);
    if (!$user_id || !check_admin_referer('cininvest_admin_verify_reject_' . $user_id, 'cininvest_admin_nonce')) {
        wp_die('Ошибка безопасности');
    }
    update_user_meta($user_id, 'cininvest_verify_status', 'rejected');
    update_user_meta($user_id, 'cininvest_verified', 0);
    $reason = sanitize_textarea_field(wp_unslash($_POST['reject_reason'] ?? ''));
    if ($reason !== '') { update_user_meta($user_id, 'cininvest_verify_reject_reason', $reason); }
    else { delete_user_meta($user_id, 'cininvest_verify_reject_reason'); }
    wp_safe_redirect(add_query_arg(['page' => 'cininvest-verifications', 'user_id' => $user_id, 'cininvest_notice' => 'rejected'], admin_url('admin.php')));
    exit;
});

/** Колонка «Верификация CININVEST» в списке Пользователи — видно сразу, без захода в каждый профиль */
add_filter('manage_users_columns', function ($columns) {
    $columns['cininvest_verify'] = 'Верификация CININVEST';
    return $columns;
});
add_filter('manage_users_custom_column', function ($value, $column_name, $user_id) {
    if ($column_name !== 'cininvest_verify') return $value;
    $status = get_user_meta($user_id, 'cininvest_verify_status', true);
    if ($status === '') return '—';
    $url = esc_url(add_query_arg(['page' => 'cininvest-verifications', 'user_id' => $user_id], admin_url('admin.php')));
    return '<a href="' . $url . '">' . cininvest_admin_verify_badge($status) . '</a>';
}, 10, 3);

/* =========================================================================
 * 8. Финансовые операции — витрина wp_cininvest_operations (только просмотр
 *    + экспорт CSV). Статус НЕ редактируется вручную намеренно: под мок-шлюзом
 *    (inc/payment-gateway.php) баланс меняется синхронно с операцией, отдельного
 *    отката баланса нет — ручная правка статуса создала бы расхождение с
 *    балансом. Когда подключится реальный банк с вебхуком (inc/rest-webhook.php),
 *    статус будет меняться только через него.
 * ========================================================================= */

function cininvest_admin_op_type_label($type) {
    $labels = ['buy' => 'Покупка долей', 'privileges' => 'Спонсорство', 'deposit' => 'Пополнение', 'withdraw' => 'Вывод'];
    return $labels[$type] ?? esc_html($type);
}
function cininvest_admin_op_status_badge($status) {
    $class = ['pending' => 'checking', 'completed' => 'completed', 'failed' => 'rejected'][$status] ?? 'none';
    $labels = ['pending' => 'Ожидает', 'completed' => 'Завершена', 'failed' => 'Неуспешна'];
    return '<span class="cininvest-badge cininvest-badge--' . esc_attr($class) . '">' . esc_html($labels[$status] ?? $status) . '</span>';
}

/** Общие для списка/экспорта: WHERE-условие + параметры из фильтров $_GET */
function cininvest_admin_operations_query_args() {
    global $wpdb;
    $where = ['1=1'];
    $params = [];
    if (!empty($_GET['status']) && in_array($_GET['status'], ['pending', 'completed', 'failed'], true)) {
        $where[] = 'status = %s'; $params[] = $_GET['status'];
    }
    if (!empty($_GET['type']) && in_array($_GET['type'], ['buy', 'privileges', 'deposit', 'withdraw'], true)) {
        $where[] = 'type = %s'; $params[] = $_GET['type'];
    }
    if (!empty($_GET['q'])) {
        $search = sanitize_text_field(wp_unslash($_GET['q']));
        $user = get_user_by('email', $search) ?: get_user_by('login', $search);
        if ($user) { $where[] = 'user_id = %d'; $params[] = $user->ID; }
        else { $where[] = 'reference LIKE %s'; $params[] = '%' . $wpdb->esc_like($search) . '%'; }
    }
    return [implode(' AND ', $where), $params];
}

function cininvest_admin_maybe_export_operations_csv() {
    if (empty($_GET['cininvest_export']) || $_GET['cininvest_export'] !== 'csv') return;
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');
    check_admin_referer('cininvest_export_operations');

    global $wpdb;
    $table = $wpdb->prefix . 'cininvest_operations';
    [$where, $params] = cininvest_admin_operations_query_args();
    $sql = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC";
    $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params)) : $wpdb->get_results($sql);

    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=cininvest-operations-' . gmdate('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['ID', 'Дата', 'Пользователь', 'Email', 'Тип', 'Статус', 'Сумма', 'Доли', 'Проект', 'Комиссия', 'Reference']);
    foreach ($rows as $r) {
        $user = get_userdata($r->user_id);
        $project_title = $r->project_id ? get_the_title($r->project_id) : '';
        fputcsv($out, [
            $r->id, $r->created_at, $user ? $user->display_name : $r->user_id, $user ? $user->user_email : '',
            cininvest_admin_op_type_label($r->type), $r->status, $r->amount, $r->shares, $project_title, $r->commission, $r->reference,
        ]);
    }
    fclose($out);
    exit;
}

function cininvest_admin_render_operations_page() {
    if (!current_user_can('manage_options')) wp_die('Недостаточно прав');
    global $wpdb;
    $table = $wpdb->prefix . 'cininvest_operations';

    $per_page = 50;
    $paged = max(1, (int) ($_GET['paged'] ?? 1));
    [$where, $params] = cininvest_admin_operations_query_args();

    $total = $params
        ? (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where}", $params))
        : (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$where}");
    $offset = ($paged - 1) * $per_page;
    $sql = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";
    $rows = $wpdb->get_results($wpdb->prepare($sql, array_merge($params, [$per_page, $offset])));

    echo '<div class="wrap"><h1>Финансовые операции</h1>';
    echo '<p style="color:#646970">Только просмотр: статус операции отражает платёжный шлюз и не редактируется вручную.</p>';

    echo '<form method="get" style="margin:12px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap">';
    echo '<input type="hidden" name="page" value="cininvest-operations">';
    echo '<select name="status"><option value="">Все статусы</option>';
    foreach (['pending' => 'Ожидает', 'completed' => 'Завершена', 'failed' => 'Неуспешна'] as $v => $l) {
        echo '<option value="' . esc_attr($v) . '" ' . selected($_GET['status'] ?? '', $v, false) . '>' . esc_html($l) . '</option>';
    }
    echo '</select>';
    echo '<select name="type"><option value="">Все типы</option>';
    foreach (['buy' => 'Покупка долей', 'privileges' => 'Спонсорство', 'deposit' => 'Пополнение', 'withdraw' => 'Вывод'] as $v => $l) {
        echo '<option value="' . esc_attr($v) . '" ' . selected($_GET['type'] ?? '', $v, false) . '>' . esc_html($l) . '</option>';
    }
    echo '</select>';
    echo '<input type="text" name="q" value="' . esc_attr($_GET['q'] ?? '') . '" placeholder="Email, логин или reference">';
    echo '<button class="button">Фильтровать</button>';
    $export_url = wp_nonce_url(add_query_arg(array_merge($_GET, ['cininvest_export' => 'csv']), admin_url('admin.php')), 'cininvest_export_operations');
    echo '<a class="button" href="' . esc_url($export_url) . '">Экспорт CSV</a>';
    echo '</form>';

    echo '<table class="wp-list-table widefat fixed striped cininvest-table"><thead><tr>';
    echo '<th>Дата</th><th>Пользователь</th><th>Тип</th><th>Статус</th><th>Сумма</th><th>Доли</th><th>Проект</th><th>Комиссия</th><th>Reference</th>';
    echo '</tr></thead><tbody>';
    if ($rows) {
        foreach ($rows as $r) {
            $user = get_userdata($r->user_id);
            echo '<tr>';
            echo '<td>' . esc_html(mysql2date('d.m.Y H:i', $r->created_at)) . '</td>';
            echo '<td>' . ($user ? '<a href="' . esc_url(get_edit_user_link($user->ID)) . '">' . esc_html($user->display_name) . '</a>' : esc_html((string) $r->user_id)) . '</td>';
            echo '<td>' . cininvest_admin_op_type_label($r->type) . '</td>';
            echo '<td>' . cininvest_admin_op_status_badge($r->status) . '</td>';
            echo '<td>' . esc_html(cininvest_admin_money($r->amount)) . '</td>';
            echo '<td>' . ($r->shares !== null ? (int) $r->shares : '—') . '</td>';
            echo '<td>' . ($r->project_id ? '<a href="' . esc_url(get_edit_post_link($r->project_id)) . '">' . esc_html(get_the_title($r->project_id)) . '</a>' : '—') . '</td>';
            echo '<td>' . ($r->commission !== null ? esc_html(cininvest_admin_money($r->commission)) : '—') . '</td>';
            echo '<td><code style="font-size:11px">' . esc_html($r->reference) . '</code></td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="9">Операции не найдены.</td></tr>';
    }
    echo '</tbody></table>';

    $total_pages = (int) ceil($total / $per_page);
    if ($total_pages > 1) {
        echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links([
            'base' => add_query_arg('paged', '%#%'), 'format' => '', 'current' => $paged, 'total' => $total_pages,
        ]) . '</div></div>';
    }
    echo '</div>';
}

/* =========================================================================
 * 9. Управление проектами: колонка сбора средств в списке «Проекты» +
 *    быстрая правка ключевых ACF-полей прямо из списка (Quick Edit), без
 *    открытия каждого проекта. Срабатывает только когда наш nonce/поля
 *    реально присутствуют в запросе — обычное сохранение через редактор
 *    (ACF-метабокс) эту логику не задевает. В массовом («Bulk Edit») режиме
 *    числовые поля намеренно остаются пустыми, поэтому массово ничего не
 *    затирается; статус меняется массово, только если явно выбран в списке.
 * ========================================================================= */

add_filter('manage_project_posts_columns', function ($columns) {
    $date = $columns['date'] ?? null;
    unset($columns['date']);
    $columns['cininvest_funding'] = 'Сбор средств (CININVEST)';
    if ($date) $columns['date'] = $date;
    return $columns;
});

add_action('manage_project_posts_custom_column', function ($column, $post_id) {
    if ($column !== 'cininvest_funding') return;

    $goal = (float) cininvest_field('goal', $post_id, 0);
    $collected = (float) cininvest_field('collected', $post_id, 0);
    $share_price = (float) cininvest_field('share_price', $post_id, 0);
    $commission = (float) cininvest_field('commission', $post_id, 0);
    $shares_available = (int) cininvest_field('shares_available', $post_id, 0);
    $status = (string) cininvest_field('project_status', $post_id, 'active');
    if ($status === '') $status = 'active';
    $percent = $goal > 0 ? min(100, round($collected / $goal * 100)) : 0;

    echo '<div>' . esc_html(cininvest_admin_money($collected)) . ' из ' . esc_html(cininvest_admin_money($goal)) . ' (' . esc_html($percent) . '%)</div>';
    echo '<div style="color:#646970;font-size:12px">' . esc_html($status === 'completed' ? 'Завершён' : 'В работе') . ' · долей доступно: ' . esc_html($shares_available) . '</div>';

    echo '<div id="cininvest-qe-data-' . (int) $post_id . '" class="cininvest-qe-data" style="display:none"'
        . ' data-goal="' . esc_attr($goal) . '" data-collected="' . esc_attr($collected) . '"'
        . ' data-share_price="' . esc_attr($share_price) . '" data-commission="' . esc_attr($commission) . '"'
        . ' data-shares_available="' . esc_attr($shares_available) . '" data-status="' . esc_attr($status) . '"></div>';
}, 10, 2);

add_action('quick_edit_custom_box', function ($column_name, $post_type) {
    if ($column_name !== 'cininvest_funding' || $post_type !== 'project') return;
    wp_nonce_field('cininvest_quick_edit_project', 'cininvest_quick_edit_nonce');
    echo '<fieldset class="inline-edit-col-right inline-edit-cininvest"><div class="inline-edit-col">';
    echo '<h4>CININVEST</h4>';
    foreach ([
        'cininvest_goal' => 'Цель, ₽', 'cininvest_collected' => 'Собрано, ₽', 'cininvest_share_price' => 'Цена за долю, ₽',
        'cininvest_commission' => 'Комиссия, %', 'cininvest_shares_available' => 'Доступно долей',
    ] as $name => $label) {
        $field = substr($name, strlen('cininvest_'));
        echo '<label class="inline-edit-group"><span class="title">' . esc_html($label) . '</span><span class="input-text-wrap"><input type="text" name="' . esc_attr($name) . '" class="cininvest-qe-input" data-field="' . esc_attr($field) . '"></span></label>';
    }
    echo '<label class="inline-edit-group"><span class="title">Статус сбора</span><span class="input-text-wrap"><select name="cininvest_project_status" class="cininvest-qe-input" data-field="status">';
    echo '<option value="">— не менять —</option><option value="active">В работе</option><option value="completed">Завершён</option>';
    echo '</select></span></label>';
    echo '</div></fieldset>';
}, 10, 2);

add_action('admin_footer-edit.php', function () {
    global $post_type;
    if ($post_type !== 'project') return;
    ?>
    <script>
    jQuery(function ($) {
        if (typeof inlineEditPost === 'undefined') return;
        var cininvestOrigEdit = inlineEditPost.edit;
        inlineEditPost.edit = function (id) {
            cininvestOrigEdit.apply(this, arguments);
            var postId = (typeof id === 'object') ? parseInt(this.getId(id), 10) : parseInt(id, 10);
            if (!postId) return;
            var data = document.getElementById('cininvest-qe-data-' + postId);
            var row = document.getElementById('edit-' + postId);
            if (!data || !row) return;
            row.querySelectorAll('.cininvest-qe-input').forEach(function (input) {
                var field = input.getAttribute('data-field');
                var val = data.getAttribute('data-' + field);
                if (val === null) return;
                if (input.tagName === 'SELECT') {
                    var has = [].slice.call(input.options).some(function (o) { return o.value === val; });
                    if (has) input.value = val;
                } else {
                    input.value = val;
                }
            });
        };
    });
    </script>
    <?php
});

add_action('save_post_project', function ($post_id) {
    if (!isset($_POST['cininvest_quick_edit_nonce']) || !wp_verify_nonce($_POST['cininvest_quick_edit_nonce'], 'cininvest_quick_edit_project')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (!function_exists('update_field')) return;

    $numeric_map = [
        'cininvest_goal' => 'goal', 'cininvest_collected' => 'collected', 'cininvest_share_price' => 'share_price',
        'cininvest_commission' => 'commission', 'cininvest_shares_available' => 'shares_available',
    ];
    foreach ($numeric_map as $post_key => $acf_key) {
        if (isset($_POST[$post_key]) && $_POST[$post_key] !== '') {
            $val = (float) str_replace(',', '.', wp_unslash($_POST[$post_key]));
            update_field($acf_key, $val, $post_id);
        }
    }
    if (!empty($_POST['cininvest_project_status']) && in_array($_POST['cininvest_project_status'], ['active', 'completed'], true)) {
        update_field('project_status', $_POST['cininvest_project_status'], $post_id);
    }
});
